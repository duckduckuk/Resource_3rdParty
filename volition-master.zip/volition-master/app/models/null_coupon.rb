class NullCoupon
  def id
    ""
  end
end

