class NullSubscription
  def active?
    false
  end

  def stripe_id
    nil
  end
end
