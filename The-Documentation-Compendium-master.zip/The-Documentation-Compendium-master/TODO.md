### TODO

---

- [x] Document the README.md file in the [README Templates](/README%20Templates) folder.
- [ ] Make an IoT template (Refer to the various Arduino project documentations for assistance). This template must be detailed and should go in-depth into the various hardware terminologies
- [ ] Make a minimal IoT template.
- [ ] Add a COMMIT_MESSAGE_GUIDELINES.md file.
- [ ] Translate the various [templates](https://github.com/kylelobo/The-Documentation-Compendium#templates) into different languages - Chinese, Spanish, Portuguese, Russian, etc.
