export default [
  { label: 'Template #1', value: 'EmailTemplate1' },
  { label: 'Template #2', value: 'EmailTemplate2' },
  { label: 'Template #3', value: 'EmailTemplate3' }
]
